<?php
/**
 * JailTrak - Main Configuration
 * You can add additional custom config options here as needed.
 */

// Example: Database settings (already handled via constants.php and DB_PATH)
return [
    // Add other config options as needed
];
?>