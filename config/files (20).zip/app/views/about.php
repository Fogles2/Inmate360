<?php
// JailTrak - About Page (stub)
echo "<h2>About JailTrak</h2>";
?>