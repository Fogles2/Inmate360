<?php
// JailTrak - Probation Case Listing View (stub)
echo "<h2>Probation Case Manager</h2>";
?>